const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

export const getImageUrl = (path: string): string => {
  if (!path) return '';

  // If path already contains http/https, return as is
  if (path.startsWith('http://') || path.startsWith('https://')) {
    return path;
  }

  // If path starts with /, it's a relative path from server root
  if (path.startsWith('/')) {
    return `${API_BASE_URL}${path}`;
  }

  // Otherwise, assume it needs /uploads/ prefix
  return `${API_BASE_URL}/uploads/${path}`;
};
