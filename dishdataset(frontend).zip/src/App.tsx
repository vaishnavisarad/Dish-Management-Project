import { useEffect, useState, useRef, useCallback } from 'react';

// import login page
import Login from "./components/Login";

// ======== ⬇️ LOGIN WRAPPER CODE ADDED HERE ⬇️ ========

function AppWrapper() {
  const [user, setUser] = useState<string | null>(
    localStorage.getItem("loggedInUser")
  );

  const handleLogin = (username: string) => {
    setUser(username);
    localStorage.setItem("loggedInUser", username);
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem("loggedInUser");
  };

  return user ? (
    <App onLogout={handleLogout} />
  ) : (
    <Login onLogin={handleLogin} />
  );
}

export default AppWrapper;

// ======== ⬆️ LOGIN WRAPPER CODE ADDED HERE ⬆️ ========


// ================== ORIGINAL APP CODE BELOW ==================
import { Plus, LogOut, Compass } from 'lucide-react';
import { dishApi } from './services/api';
import type { DishWithImages } from './services/api';
import DishList from './components/DishList';
import DishForm from './components/DishForm';
import DishDetail from './components/DishDetail';
import ExploreDishes from './components/ExploreDishes';
import debounce from 'lodash.debounce';

function App({ onLogout }: { onLogout: () => void }) {
  const [currentView, setCurrentView] = useState<'dashboard' | 'explore'>('dashboard');
  const [dishes, setDishes] = useState<DishWithImages[]>([]);
  const [selectedDish, setSelectedDish] = useState<DishWithImages | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingDish, setEditingDish] = useState<DishWithImages | null>(null);
  const [loading, setLoading] = useState(true);
  const [modalClosing, setModalClosing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    total: 0,
    totalPages: 0
  });

  const formRef = useRef<HTMLDivElement>(null);
  const detailRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchDishes();
  }, [currentPage]);

  const fetchDishes = async (search?: string, page?: number) => {
    setLoading(true);
    try {
      const result = await dishApi.getAllDishes(
        search,
        page || currentPage,
        itemsPerPage
      );
      setDishes(result.dishes);
      setPagination(result.pagination);
    } catch (error) {
      console.error('Error fetching dishes:', error);
    } finally {
      setLoading(false);
    }
  };

  const debouncedSearch = useCallback(
    debounce((query: string) => {
      setCurrentPage(1);
      fetchDishes(query, 1);
    }, 500),
    []
  );

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    debouncedSearch(query);
  };

  useEffect(() => {
    return () => debouncedSearch.cancel();
  }, [debouncedSearch]);

  const handleAddDish = () => {
    setEditingDish(null);
    setIsFormOpen(true);
    setSelectedDish(null);
  };

  const handleEditDish = (dish: DishWithImages) => {
    setEditingDish(dish);
    setIsFormOpen(true);
    setSelectedDish(null);
  };

  const handleDeleteDish = async (dishId: string) => {
    if (!confirm('Are you sure you want to delete this dish?')) return;

    try {
      await dishApi.deleteDish(dishId);
      await fetchDishes(searchQuery, currentPage);
      if (selectedDish?.id === dishId) setSelectedDish(null);
    } catch (error) {
      console.error('Error deleting dish:', error);
      alert('Failed to delete dish');
    }
  };

  const handleFormSuccess = async (existingDish?: DishWithImages) => {
    await fetchDishes(searchQuery, currentPage);

    if (existingDish) {
      setSelectedDish(existingDish);
      setIsFormOpen(false);
    } else {
      await closeModal();
    }
  };

  const closeModal = async (resetSelectedDish = true) => {
    setModalClosing(true);
    await new Promise((resolve) => setTimeout(resolve, 300));
    setModalClosing(false);
    setIsFormOpen(false);
    setEditingDish(null);

    if (resetSelectedDish) setSelectedDish(null);
  };

  const handleViewDish = (dish: DishWithImages) => {
    setSelectedDish(dish);
    setIsFormOpen(false);
  };

  const handleClickOutside = (e: MouseEvent) => {
    if (
      (isFormOpen && formRef.current && !formRef.current.contains(e.target as Node)) ||
      (selectedDish && detailRef.current && !detailRef.current.contains(e.target as Node))
    ) {
      closeModal();
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isFormOpen, selectedDish]);

  if (currentView === 'explore') {
    return <ExploreDishes onBack={() => setCurrentView('dashboard')} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-amber-50">
      <div className="container mx-auto px-4 py-8 max-w-7xl">

        {/* Header */}
        <header className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">Dish Explorer</h1>
              <p className="text-gray-600">Discover and manage dishes from around the world</p>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setCurrentView('explore')}
                className="flex items-center gap-2 bg-amber-600 hover:bg-amber-700 text-white px-6 py-3 rounded-lg font-medium transition-colors shadow-lg hover:shadow-xl"
              >
                <Compass size={20} />
                Explore Dishes
              </button>

              <button
                onClick={handleAddDish}
                className="flex items-center gap-2 bg-orange-600 hover:bg-orange-700 text-white px-6 py-3 rounded-lg font-medium transition-colors shadow-lg hover:shadow-xl"
              >
                <Plus size={20} />
                Add New Dish
              </button>

              <button
                onClick={onLogout}
                 className="flex items-center gap-2 bg-gray-600 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-medium transition-colors shadow-lg hover:shadow-xl"
              >
                <LogOut size={20} />
                Logout
              </button>
            </div>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={handleSearchChange}
              placeholder="Search dishes..."
              className="w-full px-4 py-3 pl-12 border border-gray-300 rounded-lg"
            />
          </div>
        </header>

        <div className="w-full">
          <DishList
            dishes={dishes}
            loading={loading}
            onViewDish={handleViewDish}
            onEditDish={handleEditDish}
            onDeleteDish={handleDeleteDish}
            selectedDishId={selectedDish?.id}
            pagination={pagination}
            currentPage={currentPage}
            onPageChange={setCurrentPage}
          />
        </div>
      </div>

      {/* Dish Detail Modal */}
      {selectedDish && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center p-8 z-50">
          <div ref={detailRef} className="bg-white rounded-xl shadow-lg p-8 w-full max-w-4xl">
            <DishDetail
              dish={selectedDish}
              onEdit={() => handleEditDish(selectedDish)}
              onClose={closeModal}
            />
          </div>
        </div>
      )}

      {/* Add/Edit Form Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center p-8 z-50">
          <div ref={formRef} className="bg-white rounded-xl shadow-lg p-8 w-full max-w-3xl">
            <DishForm
              dish={editingDish}
              onSuccess={handleFormSuccess}
              onCancel={closeModal}
              selectedDish={selectedDish}
            />
          </div>
        </div>
      )}
    </div>
  );
}
