const API_BASE_URL = `${import.meta.env.VITE_API_BASE_URL}/api`;;

interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  pagination?: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface Dish {
  id: string;
  name: string;
  location_country: string;
  location_region: string;
  location_city: string;
  dish_type: string;
  food_type?: string; // 🍽️ Added this line (Veg / Non-Veg)
  main_ingredient: string;
  cooking_method: string;
  cuisine_style: string;
  cusine_group: string;
  taste_profile: string;
  occasion: string;
  description: string;
  famous_for: string;
  created_at: string;
  updated_at: string;
}

export interface DishImage {
  id: string;
  dish_id: string;
  image_url: string;
  is_primary: boolean;
  created_at: string;
}

export interface DishWithImages extends Dish {
  cuisine_group: string;
  dish_images: DishImage[];
}

export const dishApi = {
  // 🔹 Fetch all dishes (with optional search and pagination)
  async getAllDishes(
    searchQuery?: string,
    page: number = 1,
    limit: number = 10
  ): Promise<{
    dishes: DishWithImages[];
    pagination: {
      page: number;
      limit: number;
      total: number;
      totalPages: number;
    };
  }> {
    const params = new URLSearchParams();
    if (searchQuery) params.append('search', searchQuery);
    params.append('page', page.toString());
    params.append('limit', limit.toString());

    const url = `${API_BASE_URL}/dishes?${params.toString()}`;
    const response = await fetch(url);
    const result: ApiResponse<DishWithImages[]> = await response.json();
    if (!result.success) throw new Error(result.message);

    return {
      dishes: result.data || [],
      pagination: result.pagination || { page: 1, limit: 10, total: 0, totalPages: 0 }
    };
  },

  // 🔹 Get single dish
  async getDishById(id: string): Promise<DishWithImages> {
    const response = await fetch(`${API_BASE_URL}/dishes/${id}`);
    const result: ApiResponse<DishWithImages> = await response.json();
    if (!result.success) throw new Error(result.message);
    return result.data!;
  },

  // 🔹 Create dish (supports food_type)
  async createDish(dishData: Partial<Dish>): Promise<Dish> {
    const response = await fetch(`${API_BASE_URL}/dishes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dishData),
    });
    const result: ApiResponse<Dish> = await response.json();
    if (!result.success) throw new Error(result.message);
    return result.data!;
  },

  // 🔹 Update dish (supports food_type)
  async updateDish(id: string, dishData: Partial<Dish>): Promise<Dish> {
    const response = await fetch(`${API_BASE_URL}/dishes/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dishData),
    });
    const result: ApiResponse<Dish> = await response.json();
    if (!result.success) throw new Error(result.message);
    return result.data!;
  },

  // 🔹 Delete dish
  async deleteDish(id: string): Promise<void> {
    const response = await fetch(`${API_BASE_URL}/dishes/${id}`, {
      method: 'DELETE',
    });
    const result: ApiResponse<void> = await response.json();
    if (!result.success) throw new Error(result.message);
  },
};

export const imageApi = {
  async getDishImages(dishId: string): Promise<DishImage[]> {
    const response = await fetch(`${API_BASE_URL}/images/dish/${dishId}`);
    const result: ApiResponse<DishImage[]> = await response.json();
    if (!result.success) throw new Error(result.message);
    return result.data || [];
  },

  async addDishImage(imageData: {
    dish_id: string;
    image_url: string;
    is_primary: boolean;
  }): Promise<DishImage> {
    const response = await fetch(`${API_BASE_URL}/images`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(imageData),
    });
    const result: ApiResponse<DishImage> = await response.json();
    if (!result.success) throw new Error(result.message);
    return result.data!;
  },

  async addMultipleDishImages(images: Array<{
    dish_id: string;
    image_url: string;
    is_primary: boolean;
  }>): Promise<DishImage[]> {
    const response = await fetch(`${API_BASE_URL}/images/multiple`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ images }),
    });
    const result: ApiResponse<DishImage[]> = await response.json();
    if (!result.success) throw new Error(result.message);
    return result.data!;
  },

  async updateDishImage(id: string, is_primary: boolean): Promise<DishImage> {
    const response = await fetch(`${API_BASE_URL}/images/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ is_primary }),
    });
    const result: ApiResponse<DishImage> = await response.json();
    if (!result.success) throw new Error(result.message);
    return result.data!;
  },

  async deleteDishImage(id: string): Promise<void> {
    const response = await fetch(`${API_BASE_URL}/images/${id}`, {
      method: 'DELETE',
    });
    const result: ApiResponse<void> = await response.json();
    if (!result.success) throw new Error(result.message);
  },
};
