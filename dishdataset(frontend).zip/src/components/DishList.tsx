import { Edit2, Trash2, MapPin, Utensils, ChevronLeft, ChevronRight} from 'lucide-react';
import { getImageUrl } from '../utils/imageUrl';
import type { DishWithImages } from '../services/api';

const FoodTypeBadge = ({ type }: { type?: string }) => {
  if (!type) return null;

  const isVeg = type.toLowerCase() === 'veg';

  return (
    <div className="flex items-center gap-2 mt-2">
      <div
        className={`w-4 h-4 border-2 rounded-sm flex items-center justify-center ${
          isVeg ? 'border-green-600' : 'border-yellow-600'
        }`}
      >
        <div
          className={`w-2 h-2 rounded-full ${
            isVeg ? 'bg-green-600' : 'bg-yellow-500'
          }`}
        />
      </div>
      <span
        className={`text-sm font-medium ${
          isVeg ? 'text-green-700' : 'text-yellow-700'
        }`}
      >
        {isVeg ? 'Veg' : 'Non-Veg'}
      </span>
    </div>
  );
};


interface DishListProps {
  dishes: DishWithImages[];
  loading: boolean;
  onViewDish: (dish: DishWithImages) => void;
  onEditDish: (dish: DishWithImages) => void;
  onDeleteDish: (dishId: string) => void;
  selectedDishId?: string;
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
  currentPage: number;
  onPageChange: (page: number) => void;
}

export default function DishList({
  dishes,
  loading,
  onViewDish,
  onEditDish,
  onDeleteDish,
  selectedDishId,
  pagination,
  currentPage,
  onPageChange,
}: DishListProps) {
  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100">
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="animate-pulse flex gap-4">
              <div className="w-24 h-24 bg-gray-200 rounded-lg"></div>
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                <div className="h-3 bg-gray-200 rounded w-2/3"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (dishes.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-12 text-center border border-gray-100">
        <div className="text-gray-400 mb-4">
          <svg
            className="w-24 h-24 mx-auto"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"
            />
          </svg>
        </div>
        <h3 className="text-xl font-semibold text-gray-700 mb-2">
          No Dishes Yet
        </h3>
        <p className="text-gray-500">
          Start by adding your first dish to the collection
        </p>
      </div>
    );
  }

  const renderPagination = () => {
    if (pagination.totalPages <= 1) return null;

    const pages = [];
    const maxVisiblePages = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(pagination.totalPages, startPage + maxVisiblePages - 1);

    if (endPage - startPage < maxVisiblePages - 1) {
      startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }

    return (
      <div className="flex items-center justify-between border-t border-gray-200 pt-4 mt-4">
        <div className="text-sm text-gray-600">
          Showing {Math.min((currentPage - 1) * pagination.limit + 1, pagination.total)} to{' '}
          {Math.min(currentPage * pagination.limit, pagination.total)} of {pagination.total} dishes
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onPageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className="p-2 rounded-lg border border-gray-300 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronLeft size={18} />
          </button>

          {startPage > 1 && (
            <>
              <button
                onClick={() => onPageChange(1)}
                className="px-3 py-1 rounded-lg border border-gray-300 hover:bg-gray-50 transition-colors"
              >
                1
              </button>
              {startPage > 2 && <span className="text-gray-400">...</span>}
            </>
          )}

          {pages.map((page) => (
            <button
              key={page}
              onClick={() => onPageChange(page)}
              className={`px-3 py-1 rounded-lg border transition-colors ${
                page === currentPage
                  ? 'bg-orange-600 text-white border-orange-600'
                  : 'border-gray-300 hover:bg-gray-50'
              }`}
            >
              {page}
            </button>
          ))}

          {endPage < pagination.totalPages && (
            <>
              {endPage < pagination.totalPages - 1 && <span className="text-gray-400">...</span>}
              <button
                onClick={() => onPageChange(pagination.totalPages)}
                className="px-3 py-1 rounded-lg border border-gray-300 hover:bg-gray-50 transition-colors"
              >
                {pagination.totalPages}
              </button>
            </>
          )}

          <button
            onClick={() => onPageChange(currentPage + 1)}
            disabled={currentPage === pagination.totalPages}
            className="p-2 rounded-lg border border-gray-300 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronRight size={18} />
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100">
      <div className="p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">
          All Dishes ({pagination.total})
        </h2>
        <div className="space-y-3">
          {dishes.map((dish) => {
            const primaryImage = dish.dish_images.find((img) => img.is_primary);
            const displayImage = primaryImage || dish.dish_images[0];
            const isSelected = selectedDishId === dish.id;

            return (
              <div
                key={dish.id}
                onClick={() => onViewDish(dish)}
                className={`border rounded-lg p-4 flex gap-4 transition-all cursor-pointer hover:shadow-md ${
                  isSelected
                    ? 'border-orange-500 bg-orange-50 shadow-md'
                    : 'border-gray-200 hover:border-orange-300'
                }`}
              >
                {/* 🖼️ Image */}
                <div className="flex-shrink-0">
                    {displayImage ? (
                      <img
                        src={getImageUrl(displayImage.image_url)}
                        alt={dish.name}
                        className="w-24 h-24 object-cover rounded-lg"
                      />
                    ) : (
                      <div className="w-24 h-24 bg-gray-100 rounded-lg flex items-center justify-center">
                        <svg
                          className="w-10 h-10 text-gray-400"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                          />
                        </svg>
                      </div>
                    )}
                  </div>

                {/* 📝 Dish Details */}
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-lg text-gray-900 mb-1 truncate">
                    {dish.name}
                  </h3>

                  {(dish.location_country || dish.location_city) && (
                    <div className="flex items-center gap-1 text-sm text-gray-600 mb-2">
                      <MapPin size={14} />
                      <span className="truncate">
                        {[dish.location_city, dish.location_country]
                          .filter(Boolean)
                          .join(', ')}
                      </span>
                    </div>
                  )}

                  {/* 🍽️ Dish Type */}
                  {dish.dish_type && (
                    <div className="flex items-center gap-2 text-sm text-gray-700">
                      <Utensils size={14} className="text-amber-700" />
                      <span className="font-medium">{dish.dish_type}</span>
                    </div>
                  )}

                   {/* 🍛 Food Type */}
                 {dish.food_type && <FoodTypeBadge type={dish.food_type} />}

                </div>

                {/* ✏️ Action Buttons */}
                <div className="flex flex-col gap-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onEditDish(dish);
                    }}
                    className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    title="Edit"
                  >
                    <Edit2 size={18} />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteDish(dish.id);
                    }}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    title="Delete"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {renderPagination()}
      </div>
    </div>
  );
}
