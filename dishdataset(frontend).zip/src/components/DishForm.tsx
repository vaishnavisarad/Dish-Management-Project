import { useState, useEffect, useCallback } from "react";
import { X, Upload, Trash2, Star } from "lucide-react";
import { dishApi } from "../services/api";
import { getImageUrl } from "../utils/imageUrl.ts";
import debounce from "lodash.debounce";
import type { DishWithImages } from "../services/api";

interface DishFormProps {
  selectedDish: DishWithImages | null;
  dish: DishWithImages | null;
  onSuccess: (existingDish?: DishWithImages) => void;
  onCancel: () => void;
}

interface ImagePreview {
  id?: string;
  url: string;
  isPrimary: boolean;
  file?: File;
}

export default function DishForm({
  dish,
  onSuccess,
  selectedDish,
  onCancel,
}: DishFormProps) {
  const [formData, setFormData] = useState({
    name: "",
    location_country: "",
    location_region: "",
    location_city: "",
    dish_type: "",
    main_ingredient: "",
    cooking_method: "",
    cuisine_style: "",
    cuisine_group: "",
    taste_profile: "",
    occasion: "",
    description: "",
    famous_for: "",
    food_type: "veg",
  });

  const [images, setImages] = useState<ImagePreview[]>([]);
  const [originalImages, setOriginalImages] = useState<ImagePreview[]>([]);
  const [deletedImageIds, setDeletedImageIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [dishExists, setDishExists] = useState(false);
  const [dishMessage, setDishMessage] = useState("");

  // ✅ Populate form when editing
  useEffect(() => {
    const d = dish || selectedDish;
    if (d) {
      const formattedImages = d.dish_images.map((img) => ({
        id: img.id,
        url: img.image_url,
        isPrimary: !!img.is_primary,
      }));

      setFormData({
        name: d.name || "",
        location_country: d.location_country || "",
        location_region: d.location_region || "",
        location_city: d.location_city || "",
        dish_type: d.dish_type || "",
        main_ingredient: d.main_ingredient || "",
        cooking_method: d.cooking_method || "",
        cuisine_style: d.cuisine_style || "",
        cuisine_group: d.cuisine_group || "",
        taste_profile: d.taste_profile || "",
        occasion: d.occasion || "",
        description: d.description || "",
        famous_for: d.famous_for || "",
        food_type: d.food_type || "veg",
      });

      setImages(formattedImages);
      setOriginalImages(formattedImages);
      setDeletedImageIds([]);
    }
  }, [dish, selectedDish]);

  // ✅ Debounced duplicate check
  const checkDishExists = useCallback(
    debounce(async (name: string) => {
      if (!name.trim() || name.length < 2) {
        setDishExists(false);
        setDishMessage("");
        return;
      }

      try {
        const res = await fetch(
          `${import.meta.env.VITE_API_BASE_URL}/api/dishes/check?name=${encodeURIComponent(
            name
          )}`
        );
        const data = await res.json();

        if (data.exists) {
          setDishExists(true);
          setDishMessage("⚠️ Dish already exists!");
        } else {
          setDishExists(false);
          setDishMessage("");
        }
      } catch (err) {
        console.error("Error checking dish:", err);
        setDishExists(false);
        setDishMessage("");
      }
    }, 500),
    []
  );

  // Cleanup debounce on unmount
  useEffect(() => {
    return () => checkDishExists.cancel();
  }, [checkDishExists]);

  // ✅ Input change
  const handleInputChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    if (name === "name") checkDishExists(value);
  };

  // ✅ Upload images
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;

     const formDataObj = new FormData();

  // ✅ SEND dishName FIRST (CRITICAL)
  formDataObj.append("dishName", formData.name);
  formDataObj.append("cuisine_group", formData.cuisine_group);
  console.log("*****",formData.cuisine_group);
  console.log("FORM DATA AT UPLOAD TIME:", formData);



  // ✅ THEN send images
  files.forEach((file) => formDataObj.append("images", file));

    try {
      const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/uploads/multiple`, {
        method: "POST",
        body: formDataObj,
      });
      const data = await res.json();
      if (!data.success) throw new Error("Image upload failed");

      setImages((prev) => [
        ...prev,
        ...data.urls.map((urlObj: { url: string }, idx: number) => ({
          url: urlObj.url,
          isPrimary: prev.length + idx === 0,
        })),
      ]);
    } catch (err) {
      console.error("❌ Image upload failed:", err);
      alert("Failed to upload images");
    }
  };

  // ✅ Remove image
  const removeImage = (index: number) => {
    setImages((prev) => {
      const imageToRemove = prev[index];

      if (imageToRemove.id) {
        setDeletedImageIds((prevDeleted) => [...prevDeleted, imageToRemove.id!]);
      }

      const newImgs = prev.filter((_, i) => i !== index);
      if (prev[index].isPrimary && newImgs.length > 0)
        newImgs[0].isPrimary = true;
      return newImgs;
    });
  };

  // ✅ Set primary image
  const setPrimaryImage = (index: number) => {
    setImages((prev) =>
      prev.map((img, i) => ({ ...img, isPrimary: i === index }))
    );
  };

  // ✅ Compare if images changed
  const imagesChanged = () => {
    if (images.length !== originalImages.length) return true;

    for (let i = 0; i < images.length; i++) {
      const a = images[i];
      const b = originalImages[i];
      if (a.url !== b.url || a.isPrimary !== b.isPrimary) return true;
    }
    return false;
  };

  // ✅ Submit form
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return alert("Please enter a dish name");
    if (dishExists) return alert("Dish already exists!");

    setLoading(true);
    try {
      const payload: any = { ...formData };

      // Only send images if actually changed
      if (imagesChanged()) {
        payload.images = images.map((img) => ({
          id: img.id,
          url: img.url,
          is_primary: img.isPrimary,
        }));
      }

      if (dish && deletedImageIds.length > 0) {
        payload.deletedImageIds = deletedImageIds;
      }

      if (dish) {
        await dishApi.updateDish(dish.id, payload);
        alert("Dish updated successfully!");
      } else {
        await dishApi.createDish(payload);
        alert("Dish created successfully!");
      }

      onSuccess?.();
      setOriginalImages(images);
      setDeletedImageIds([]);
    } catch (err: any) {
      console.error("❌ Error saving dish:", err);
      alert("Failed to save dish. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // ✅ UI
  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 max-h-[calc(100vh-12rem)] overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between z-10">
        <h2 className="text-2xl font-bold text-gray-900">
          {dish ? "Edit Dish" : "Add New Dish"}
        </h2>
        <button
          onClick={onCancel}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <X size={24} />
        </button>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="p-6 space-y-6">
        {/* Dish Name */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            Dish Name *
          </label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleInputChange}
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:border-transparent ${
              dishExists
                ? "border-red-500 focus:ring-red-500"
                : "border-gray-300 focus:ring-orange-500"
            }`}
            required
          />
          {dishExists && (
            <p className="text-red-500 text-sm mt-1 font-medium">
              {dishMessage}
            </p>
          )}
        </div>

        
          {/* Cuisine Group */}
<div>
  <label className="block text-sm font-semibold text-gray-700 mb-2">
    Cuisine Group
  </label>
  <select
    name="cuisine_group"
    value={formData.cuisine_group}
    onChange={handleInputChange}
    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
    required
  >
    <option value="">Select Cuisine Group</option>
    <option value="Indian">Indian</option>
    <option value="French">French</option>
    <option value="European">European</option>
    <option value="Asian">Asian</option>
  </select>
</div>



        {/* Images */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            Images
          </label>
          <div className="space-y-3">
            {images.length > 0 && (
              <div className="grid grid-cols-2 gap-3">
                {images.map((image, index) => (
                  <div key={index} className="relative group">
                    <img
                      src={getImageUrl(image.url)}
                      alt={`Preview ${index + 1}`}
                      className="w-full h-32 object-cover rounded-lg border-2 border-gray-200"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all rounded-lg flex items-center justify-center gap-2">
                      <button
                        type="button"
                        onClick={() => setPrimaryImage(index)}
                        className={`p-2 rounded-lg transition-all ${
                          image.isPrimary
                            ? "bg-yellow-500 text-white"
                            : "bg-white text-gray-700 opacity-0 group-hover:opacity-100"
                        }`}
                      >
                        <Star
                          size={16}
                          fill={image.isPrimary ? "white" : "none"}
                        />
                      </button>
                      <button
                        type="button"
                        onClick={() => removeImage(index)}
                        className="p-2 bg-red-500 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-orange-500 hover:bg-orange-50 transition-colors">
              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                <Upload className="w-8 h-8 text-gray-400 mb-2" />
                <p className="text-sm text-gray-600">Click to upload images</p>
              </div>
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
                disabled={!formData.cuisine_group}
              />
            </label>
          </div>
        </div>

        {/* Other fields */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            ["location_country", "Country", "e.g., Italy"],
            ["location_region", "Region", "e.g., Tuscany"],
            ["location_city", "City", "e.g., Naples"],
            ["dish_type", "Dish Type", "e.g., Main course, Dessert"],
            ["main_ingredient", "Main Ingredient", "e.g., Chicken, Beef"],
            ["cooking_method", "Cooking Method", "e.g., Grilled, Baked"],
            ["cuisine_style", "Cuisine Style", "e.g., Mediterranean"],
            ["taste_profile", "Taste Profile", "e.g., Spicy, Sweet"],
          ].map(([key, label, placeholder]) => (
            <div key={key}>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                {label}
              </label>
              <input
                type="text"
                name={key}
                value={(formData as any)[key]}
                onChange={handleInputChange}
                placeholder={placeholder}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>
          ))}

          {/* Food Type */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Food Type
            </label>
            <select
              name="food_type"
              value={formData.food_type}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            >
              <option value="veg">Veg</option>
              <option value="non-veg">Non-Veg</option>
            </select>
          </div>

          {/* Occasion */}
          <div className="md:col-span-2">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Occasion
            </label>
            <input
              type="text"
              name="occasion"
              value={formData.occasion}
              onChange={handleInputChange}
              placeholder="e.g., Holiday, Breakfast"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            Description
          </label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleInputChange}
            rows={4}
            placeholder="Describe the dish..."
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 resize-none"
          />
        </div>

        {/* Famous For */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            Famous For
          </label>
          <textarea
            name="famous_for"
            value={formData.famous_for}
            onChange={handleInputChange}
            rows={3}
            placeholder="What makes this dish special?"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 resize-none"
          />
        </div>

        {/* Buttons */}
        <div className="flex gap-3 pt-4 border-t border-gray-200">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium"
            disabled={loading}
          >
            Cancel
          </button>
          <button
            type="submit"
            className="flex-1 px-6 py-3 bg-orange-600 hover:bg-orange-700 text-white rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={loading || dishExists}
          >
            {loading
              ? "Saving..."
              : dishExists
              ? "Dish Exists"
              : dish
              ? "Update Dish"
              : "Add Dish"}
          </button>
        </div>
      </form>
    </div>
  );
}
