import { useState, useEffect } from 'react';
import { ArrowLeft, Search, X } from 'lucide-react';
import { dishApi } from '../services/api';
import type { DishWithImages } from '../services/api';
import { getImageUrl } from '../utils/imageUrl';

interface ExplorePageProps {
  onBack: () => void;
}

interface CuisineGroupData {
  id: string;
  name: string;
  dishes: DishWithImages[];
  vegCount: number;
  nonVegCount: number;
  primaryImage?: string;
}

interface CategoryData {
  id: string;
  name: string;
  order: number;
  dishes: DishWithImages[];
  vegCount: number;
  nonVegCount: number;
  primaryImage?: string;
}

const PREDEFINED_CATEGORIES = [
  { id: 'breakfast', name: 'Breakfast', order: 0 }, 
  { id: 'snack', name: 'Snack', order: 1 }, // ✅ NEW
  { id: 'starter', name: 'Starter', order: 2 },
  { id: 'soup', name: 'Soup', order: 3 },
  { id: 'appetizer', name: 'Appetizer', order: 4 },
  { id: 'main', name: 'Main Course', order: 5 },
  { id: 'dessert', name: 'Dessert', order: 6 },
  { id: 'cocktail', name: 'Cocktail', order: 7 },
  { id: 'mocktail', name: 'Mocktail', order: 8 },
  { id: 'detox', name: 'Detox Juice', order: 9 },
];

const mapDishTypeToCategory = (dishType: string): string => {
  const lower = dishType.toLowerCase().trim();

  if (
    lower.includes('breakfast') ||
    lower.includes('morning') ||
    lower.includes('idli') ||
    lower.includes('dosa') ||
    lower.includes('paratha') ||
    lower.includes('poha') ||
    lower.includes('upma')
  )
    return 'breakfast';


   // 🍟 Snack
  if (
    lower.includes('snack') ||
    lower.includes('evening') ||
    lower.includes('chaat') ||
    lower.includes('pakora') ||
    lower.includes('samosa') ||
    lower.includes('vada') ||
    lower.includes('bonda') ||
    lower.includes('cutlet') ||
    lower.includes('fry')
  )
    return 'snack';

  if (lower.includes('starter')) return 'starter';
  if (lower.includes('soup')) return 'soup';
  if (lower.includes('appetizer')) return 'appetizer';
  if (lower.includes('main') || lower.includes('entree') || lower.includes('course'))
    return 'main';
  if (
    lower.includes('dessert') ||
    lower.includes('pastry') ||
    lower.includes('sweet') ||
    lower.includes('cake') ||
    lower.includes('ice cream')
  )
    return 'dessert';
  if (lower.includes('cocktail')) return 'cocktail';
  if (lower.includes('mocktail') || lower.includes('mock')) return 'mocktail';
  if (lower.includes('detox') || lower.includes('juice')) return 'detox';

  return 'main';
};

export default function ExploreDishes({ onBack }: ExplorePageProps) {
  const [allDishes, setAllDishes] = useState<DishWithImages[]>([]);
  const [cuisineGroups, setCuisineGroups] = useState<CuisineGroupData[]>([]);
  const [categoriesData, setCategoriesData] = useState<CategoryData[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  // Filters
  const [selectedCuisine, setSelectedCuisine] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedFoodType, setSelectedFoodType] = useState<'all' | 'veg' | 'non-veg'>('all');

  useEffect(() => {
    fetchAllDishes();
  }, []);

  const fetchAllDishes = async () => {
    setLoading(true);
    try {
      const result = await dishApi.getAllDishes('', 1, 1000);
      const dishes = result?.dishes || result?.data?.dishes || [];
      setAllDishes(dishes);
      organizeByCuisineGroup(dishes);
    } catch (error) {
      console.error('Error fetching dishes:', error);
    } finally {
      setLoading(false);
    }
  };

  const organizeByCuisineGroup = (dishes: DishWithImages[]) => {
    const groupMap = new Map<string, DishWithImages[]>();

    dishes.forEach((dish) => {
      const group = dish.cuisine_group || 'Other';
      if (!groupMap.has(group)) groupMap.set(group, []);
      groupMap.get(group)!.push(dish);
    });

    const groups: CuisineGroupData[] = Array.from(groupMap.entries()).map(([name, dishes]) => {
      const vegCount = dishes.filter((d) => d.food_type?.toLowerCase() === 'veg').length;
      const nonVegCount = dishes.filter((d) => d.food_type?.toLowerCase() === 'non-veg').length;
      const primaryImage = dishes.find((d) => d.dish_images?.length > 0)?.dish_images?.[0]?.image_url;

      return {
        id: name.toLowerCase().replace(/\s+/g, '-'),
        name,
        dishes,
        vegCount,
        nonVegCount,
        primaryImage,
      };
    });

    setCuisineGroups(groups);
  };

  const organizeByCategory = (dishes: DishWithImages[]) => {
    const categoryMap = new Map<string, DishWithImages[]>();

    dishes.forEach((dish) => {
      const categoryId = mapDishTypeToCategory(dish.dish_type || '');
      if (!categoryMap.has(categoryId)) categoryMap.set(categoryId, []);
      categoryMap.get(categoryId)!.push(dish);
    });

    const categories: CategoryData[] = PREDEFINED_CATEGORIES.map((cat) => {
      const dishes = categoryMap.get(cat.id) || [];
      const vegCount = dishes.filter((d) => d.food_type?.toLowerCase() === 'veg').length;
      const nonVegCount = dishes.filter((d) => d.food_type?.toLowerCase() === 'non-veg').length;
      const primaryImage = dishes.find((d) => d.dish_images?.length > 0)?.dish_images?.[0]?.image_url;

      return {
        id: cat.id,
        name: cat.name,
        order: cat.order,
        dishes,
        vegCount,
        nonVegCount,
        primaryImage,
      };
    })
      .filter((cat) => cat.dishes.length > 0)
      .sort((a, b) => a.order - b.order);

    setCategoriesData(categories);
  };

  // ✅ Correct hook order: hooks must always be at top
  useEffect(() => {
    if (!selectedCuisine) return;

    const selectedCuisineData = cuisineGroups.find((c) => c.id === selectedCuisine);
    if (selectedCuisineData) {
      organizeByCategory(selectedCuisineData.dishes);
    }
  }, [selectedCuisine, cuisineGroups]);

  const selectedCuisineData = selectedCuisine
    ? cuisineGroups.find((c) => c.id === selectedCuisine)
    : null;

  const filterBySearch = (dishes: DishWithImages[]) => {
    if (!searchQuery.trim()) return dishes;
    const query = searchQuery.toLowerCase();
    return dishes.filter(
      (dish) =>
        dish.name.toLowerCase().includes(query) ||
        dish.location_country?.toLowerCase().includes(query) ||
        dish.location_city?.toLowerCase().includes(query) ||
        dish.cuisine_style?.toLowerCase().includes(query) ||
        dish.main_ingredient?.toLowerCase().includes(query)
    );
  };

  const filterByCategory = (dishes: DishWithImages[]) => {
    if (!selectedCategory) return dishes;
    return dishes.filter((dish) => mapDishTypeToCategory(dish.dish_type || '') === selectedCategory);
  };

  const filterByFoodType = (dishes: DishWithImages[]) => {
    if (selectedFoodType === 'all') return dishes;
    return dishes.filter((dish) => dish.food_type?.toLowerCase() === selectedFoodType);
  };

  const displayedDishes = selectedCuisineData
    ? filterBySearch(
        filterByFoodType(
          filterByCategory(selectedCuisineData.dishes)
        )
      )
    : [];

  const DishCard = ({ dish }: { dish: DishWithImages }) => {
    const primaryImage = dish.dish_images.find((img) => img.is_primary) || dish.dish_images[0];
    const isVeg = dish.food_type?.toLowerCase() === 'veg';
    const imageCount = dish.dish_images?.length || 0;

    return (
      <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden border border-gray-100 group">
        <div className="relative h-40 overflow-hidden">
          {primaryImage ? (
            <img
              src={getImageUrl(primaryImage.image_url)}
              alt={dish.name}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-orange-100 to-amber-100 flex items-center justify-center">
              <Search size={40} className="text-orange-300" />
            </div>
          )}
          <div className="absolute top-2 right-2">
            <div
              className={`w-5 h-5 border-2 rounded-sm flex items-center justify-center backdrop-blur-sm ${
                isVeg ? 'border-green-600 bg-white/90' : 'border-red-600 bg-white/90'
              }`}
            >
              <div className={`w-2.5 h-2.5 rounded-full ${isVeg ? 'bg-green-600' : 'bg-red-600'}`}></div>
            </div>
          </div>
        </div>

        <div className="p-3">
          <h3 className="font-bold text-sm text-gray-900 mb-1 line-clamp-1">{dish.name}</h3>
          {imageCount > 0 && (
            <p className="text-xs text-gray-500 mt-1 flex items-center gap-1">
              <span>📸</span>
              <span>
                {imageCount} {imageCount === 1 ? 'image' : 'images'}
              </span>
            </p>
          )}
          {dish.location_city && (
            <p className="text-xs text-gray-600 mb-1 line-clamp-1">
              {dish.location_city}, {dish.location_country}
            </p>
          )}
          {dish.cuisine_style && (
            <span className="inline-block px-2 py-0.5 bg-orange-100 text-orange-700 text-xs font-medium rounded-full">
              {dish.cuisine_style}
            </span>
          )}
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-amber-50">
        <div className="container mx-auto px-4 py-8 max-w-7xl">
          <div className="animate-pulse space-y-8">
            <div className="h-12 bg-gray-200 rounded w-1/4"></div>
            <div className="h-24 bg-gray-200 rounded"></div>
            <div className="h-96 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-amber-50">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <button onClick={onBack} className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6">
          <ArrowLeft size={20} />
          Back to Dashboard
        </button>

        <h1 className="text-4xl font-bold text-gray-900 mb-2">Explore Dishes</h1>
        <p className="text-gray-600 mb-6">Browse dishes by cuisine group</p>

        <div className="relative mb-8">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search dishes, cuisines, locations..."
            className="w-full px-4 py-3 pl-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
          />
        </div>

        {/* Cuisine Group Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
          {cuisineGroups.map((cuisine) => (
            <button
              key={cuisine.id}
              onClick={() => {
                setSelectedCuisine(cuisine.id);
                setSelectedCategory(null);
                setSelectedFoodType('all');
              }}
              className={`relative overflow-hidden rounded-2xl shadow-lg transition transform hover:scale-105 text-left ${
                selectedCuisine === cuisine.id
                  ? 'border-2 border-orange-600'
                  : 'border border-gray-200'
              }`}
            >
              <div className="h-44 bg-gray-100">
                {cuisine.primaryImage ? (
                  <img
                    src={getImageUrl(cuisine.primaryImage)}
                    alt={cuisine.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-orange-100 to-amber-100">
                    <Search size={40} className="text-orange-400" />
                  </div>
                )}
              </div>

              <div className="p-4 bg-white">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-lg">{cuisine.name}</h3>
                  <span className="text-sm text-gray-500">
                    {cuisine.dishes.length} dishes
                  </span>
                </div>

                <div className="flex gap-4 mt-3 text-sm">
                  <span className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-green-600"></span>
                    Veg {cuisine.vegCount}
                  </span>
                  <span className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-red-600"></span>
                    Non-Veg {cuisine.nonVegCount}
                  </span>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Inside Selected Cuisine */}
        {selectedCuisineData ? (
          <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-3xl font-bold text-gray-900">{selectedCuisineData.name}</h2>
              <button
                onClick={() => setSelectedCuisine(null)}
                className="p-2 hover:bg-gray-100 rounded-lg"
              >
                <X size={24} className="text-gray-500" />
              </button>
            </div>

            {/* Category Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mb-6">
              {categoriesData.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`relative overflow-hidden rounded-2xl shadow-lg transition transform hover:scale-105 text-left ${
                    selectedCategory === cat.id ? 'border-2 border-orange-600' : 'border border-gray-200'
                  }`}
                >
                  <div className="h-24 bg-gray-100">
                    {cat.primaryImage ? (
                      <img
                        src={getImageUrl(cat.primaryImage)}
                        alt={cat.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-orange-100 to-amber-100">
                        <Search size={32} className="text-orange-400" />
                      </div>
                    )}
                  </div>

                  <div className="p-3 bg-white">
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-lg">{cat.name}</h3>
                      <span className="text-sm text-gray-500">
                        {cat.dishes.length} dishes
                      </span>
                    </div>

                    <div className="flex gap-4 mt-3 text-sm">
                      <span className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full bg-green-600"></span>
                        Veg {cat.vegCount}
                      </span>
                      <span className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full bg-red-600"></span>
                        Non-Veg {cat.nonVegCount}
                      </span>
                    </div>
                  </div>
                </button>
              ))}
            </div>

            {/* Veg / Non-Veg Filter */}
            <div className="flex gap-3 mb-6">
              <button
                onClick={() => setSelectedFoodType('all')}
                className={`px-4 py-2 rounded-lg font-medium transition ${
                  selectedFoodType === 'all'
                    ? 'bg-orange-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setSelectedFoodType('veg')}
                className={`px-4 py-2 rounded-lg font-medium transition ${
                  selectedFoodType === 'veg'
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Veg
              </button>
              <button
                onClick={() => setSelectedFoodType('non-veg')}
                className={`px-4 py-2 rounded-lg font-medium transition ${
                  selectedFoodType === 'non-veg'
                    ? 'bg-red-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Non-Veg
              </button>
            </div>

            {/* Dishes */}
            {displayedDishes.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {displayedDishes.map((dish) => (
                  <DishCard key={dish.id} dish={dish} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 text-gray-500">
                No dishes found for this filter
              </div>
            )}
          </div>
        ) : (
          <div className="text-center text-gray-500">
            Select a cuisine group to explore dishes.
          </div>
        )}
      </div>
    </div>
  );
}
