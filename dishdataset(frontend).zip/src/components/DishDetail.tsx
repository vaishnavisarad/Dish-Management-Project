import { useState } from 'react';
import {
  X,
  Edit2,
  MapPin,
  Utensils,
  ChefHat,
  Soup,
  Flame,
  Clock,
  Star,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { getImageUrl } from '../utils/imageUrl';
import type { DishWithImages } from '../services/api';

interface DishDetailProps {
  dish: DishWithImages;
  onEdit: () => void;
  onClose: () => void;
}

export default function DishDetail({ dish, onEdit, onClose }: DishDetailProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const images = dish.dish_images.sort((a, b) =>
    a.is_primary === b.is_primary ? 0 : a.is_primary ? -1 : 1
  );

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  // ✅ Food Type Badge
  const FoodTypeBadge = ({ type }: { type?: string }) => {
    if (!type) return null;

    const isVeg = type.toLowerCase() === 'veg';

    return (
      <div className="flex items-center gap-2 mt-2">
        <div
          className={`w-4 h-4 border-2 rounded-sm flex items-center justify-center ${
            isVeg ? 'border-green-600' : 'border-yellow-600'
          }`}
        >
          <div
            className={`w-2 h-2 rounded-full ${
              isVeg ? 'bg-green-600' : 'bg-yellow-500'
            }`}
          ></div>
        </div>
        <span
          className={`text-sm font-medium ${
            isVeg ? 'text-green-700' : 'text-yellow-700'
          }`}
        >
          {isVeg ? 'Vegetarian' : 'Non-Vegetarian'}
        </span>
      </div>
    );
  };

  // ✅ InfoSection Component
  const InfoSection = ({
    icon: Icon,
    label,
    value,
  }: {
    icon: any;
    label: string;
    value: string;
  }) => {
    if (!value) return null;

    return (
      <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
        <div className="flex-shrink-0 p-2 bg-white rounded-lg shadow-sm">
          <Icon size={20} className="text-orange-600" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">
            {label}
          </p>
          <p className="text-gray-900 font-medium">{value}</p>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 max-h-[calc(100vh-12rem)] overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between z-10">
        <h2 className="text-2xl font-bold text-gray-900">Dish Details</h2>
        <div className="flex items-center gap-2">
          <button
            onClick={onEdit}
            className="flex items-center gap-2 px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors font-medium"
          >
            <Edit2 size={18} />
            Edit
          </button>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X size={24} />
          </button>
        </div>
      </div>

      {/* Body */}
      <div className="p-6 space-y-6">
        {/* ✅ Image Carousel */}
        {images.length > 0 && (
          <div className="relative group">
            <img
              src={getImageUrl(images[currentImageIndex].image_url)}
              alt={dish.name}
              className="w-full h-80 object-cover rounded-xl shadow-md"
            />
            {images.length > 1 && (
              <>
                <button
                  onClick={prevImage}
                  className="absolute left-4 top-1/2 -translate-y-1/2 p-2 bg-white/90 hover:bg-white rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-all"
                >
                  <ChevronLeft size={24} />
                </button>
                <button
                  onClick={nextImage}
                  className="absolute right-4 top-1/2 -translate-y-1/2 p-2 bg-white/90 hover:bg-white rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-all"
                >
                  <ChevronRight size={24} />
                </button>
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                  {images.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentImageIndex(index)}
                      className={`w-2 h-2 rounded-full transition-all ${
                        index === currentImageIndex
                          ? 'bg-white w-6'
                          : 'bg-white/60 hover:bg-white/80'
                      }`}
                    />
                  ))}
                </div>
              </>
            )}
          </div>
        )}

        {/* ✅ Dish Name + Food Type */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{dish.name}</h1>
          <FoodTypeBadge type={dish.food_type} />

          {(dish.location_country || dish.location_city) && (
            <div className="flex items-center gap-2 text-gray-600 mt-2">
              <MapPin size={18} />
              <span className="text-lg">
                {[dish.location_city, dish.location_region, dish.location_country]
                  .filter(Boolean)
                  .join(', ')}
              </span>
            </div>
          )}
        </div>

        {/* Famous For */}
        {dish.famous_for && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <Star size={20} className="text-amber-600 flex-shrink-0 mt-1" />
              <div>
                <p className="text-xs font-semibold text-amber-800 uppercase tracking-wide mb-1">
                  Famous For
                </p>
                <p className="text-gray-900">{dish.famous_for}</p>
              </div>
            </div>
          </div>
        )}

        {/* Info Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <InfoSection icon={Utensils} label="Dish Type" value={dish.dish_type} />
          <InfoSection icon={Soup} label="Main Ingredient" value={dish.main_ingredient} />
          <InfoSection icon={Flame} label="Cooking Method" value={dish.cooking_method} />
          <InfoSection icon={ChefHat} label="Cuisine Style" value={dish.cuisine_style} />
          <InfoSection icon={Star} label="Taste Profile" value={dish.taste_profile} />
          <InfoSection icon={Clock} label="Occasion" value={dish.occasion} />
        </div>

        {/* Description */}
        {dish.description && (
          <div className="border-t border-gray-200 pt-6">
            <h3 className="text-lg font-bold text-gray-900 mb-3">Description</h3>
            <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">
              {dish.description}
            </p>
          </div>
        )}

        {/* All Images */}
        {images.length > 1 && (
          <div className="border-t border-gray-200 pt-6">
            <h3 className="text-lg font-bold text-gray-900 mb-3">
              All Images ({images.length})
            </h3>
            <div className="grid grid-cols-3 gap-3">
              {images.map((image, index) => (
                <div
                  key={image.id}
                  className={`relative cursor-pointer rounded-lg overflow-hidden ${
                    index === currentImageIndex
                      ? 'ring-2 ring-orange-500'
                      : 'hover:opacity-80'
                  }`}
                  onClick={() => setCurrentImageIndex(index)}
                >
                  <img
                    src={getImageUrl(image.image_url)}
                    alt={`${dish.name} ${index + 1}`}
                    className="w-full h-24 object-cover"
                  />
                  {image.is_primary && (
                    <div className="absolute top-1 right-1 p-1 bg-yellow-500 rounded-full">
                      <Star size={12} fill="white" className="text-white" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
