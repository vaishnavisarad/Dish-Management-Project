import express from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import {
  getAllDishes,
  getDishById,
  createDish,
  updateDish,
  deleteDish,
  checkDishExists
} from "../controllers/dishController.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const router = express.Router();

// Upload folder path
const uploadDir = path.join(__dirname, "../uploads");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

// Sanitize folder name
const sanitizeFolderName = (name: string): string => {
  return name
    .trim()
    .replace(/\s+/g, "_")
    .replace(/[^\w\-]/g, "")
    .toLowerCase();
};

// Multer config for dish updates
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dishName = req.body.name;

    if (dishName && dishName.trim()) {
      const folderName = sanitizeFolderName(dishName);
      const dishFolder = path.join(uploadDir, folderName);

      if (!fs.existsSync(dishFolder)) {
        fs.mkdirSync(dishFolder, { recursive: true });
        console.log("📁 Created dish folder:", dishFolder);
      }

      cb(null, dishFolder);
    } else {
      cb(null, uploadDir);
    }
  },
  filename: (req, file, cb) => {
    const safeName = file.originalname.replace(/\s+/g, "_");
    const uniqueName = `${Date.now()}-${Math.round(Math.random() * 1e9)}-${safeName}`;
    cb(null, uniqueName);
  },
});
const upload = multer({ storage });

// Dish routes


// ✅ Check if dish already exists
router.get("/check", checkDishExists);


router.get("/", getAllDishes);



router.get("/:id", getDishById);




router.post("/", createDish);



// ✅ Update dish with images
router.put("/:id", upload.array("newImages", 50), updateDish);




router.delete("/:id", deleteDish);

export default router;
