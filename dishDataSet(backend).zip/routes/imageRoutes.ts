import express from 'express';
import {
  addDishImage,
  getDishImages,
  updateDishImage,
  deleteDishImage,
  addMultipleDishImages,
} from '../controllers/imageController.js';

const router = express.Router();

router.post('/', addDishImage);
router.post('/multiple', addMultipleDishImages);
router.get('/dish/:dishId', getDishImages);
router.put('/:id', updateDishImage);
router.delete('/:id', deleteDishImage);

export default router;
