import express from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const router = express.Router();

// Upload folder path
const uploadDir = path.join(__dirname, "../uploads");

// Ensure uploads folder exists
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
  console.log("📁 Created uploads folder at:", uploadDir);
}

// 🔒 KEEP OLD SANITIZER (UNCHANGED)
const sanitizeFolderName = (name: string): string => {
  return name.trim().replace(/\s+/g, "_");
};

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dishName = req.body.dishName;
    const cuisineGroup = req.body.cuisine_group; // ✅ NEW

    if (dishName && dishName.trim()) {
      const dishFolderName = sanitizeFolderName(dishName);
      const cuisineFolderName = cuisineGroup
        ? sanitizeFolderName(cuisineGroup)
        : "Others";

      const finalFolder = path.join(
        uploadDir,
        cuisineFolderName, // 👈 NEW LEVEL
        dishFolderName
      );

      if (!fs.existsSync(finalFolder)) {
        fs.mkdirSync(finalFolder, { recursive: true });
        console.log("📁 Created folder:", finalFolder);
      }

      cb(null, finalFolder);
    } else {
      cb(null, uploadDir);
    }
  },

  filename: (req, file, cb) => {
    const nameWithoutExt = path.basename(
      file.originalname,
      path.extname(file.originalname)
    );

    const safeName = nameWithoutExt
      .replace(/\s+/g, "_")
      .replace(/[^\w\-]/g, "");

    const uniqueName = `${Date.now()}-${Math.round(
      Math.random() * 1e9
    )}-${safeName}${path.extname(file.originalname)}`;

    cb(null, uniqueName);
  },
});

const upload = multer({ storage });

router.post("/multiple", upload.array("images", 100), (req, res) => {
  console.log("📝 dishName:", req.body.dishName);
  console.log("📝 cuisine_group:", req.body.cuisine_group);

  if (!req.files || (req.files as Express.Multer.File[]).length === 0) {
    return res.status(400).json({
      success: false,
      message: "No files uploaded",
    });
  }

  const files = req.files as Express.Multer.File[];
  const dishName = req.body.dishName;
  const cuisineGroup = req.body.cuisine_group;

  const dishFolderName = dishName
    ? sanitizeFolderName(dishName)
    : "UnknownDish";

  const cuisineFolderName = cuisineGroup
    ? sanitizeFolderName(cuisineGroup)
    : "Others";

  const imageUrls = files.map((file) => ({
    url: `/uploads/${cuisineFolderName}/${dishFolderName}/${file.filename}`,
  }));

  console.log("✅ Uploaded image paths:", imageUrls);

  res.json({
    success: true,
    urls: imageUrls,
  });
});

export default router;
