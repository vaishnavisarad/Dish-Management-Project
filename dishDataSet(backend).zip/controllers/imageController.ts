import { Request, Response } from "express";
import multer from "multer";
import path from "path";
import database from "../config/database.js";

// 📁 Configure multer storage for local uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/"); // Save inside /uploads folder
  },
  filename: (req, file, cb) => {
    const uniqueName = `${Date.now()}-${Math.round(Math.random() * 1e9)}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  },
});

const upload = multer({ storage });

// ✅ Add a new dish image (manual JSON)
export const addDishImage = async (req: Request, res: Response) => {
  try {
    const { dish_id, image_url, is_primary } = req.body;

    if (!dish_id || !image_url) {
      return res.status(400).json({
        success: false,
        message: "dish_id and image_url are required",
      });
    }

    const query = `
      INSERT INTO dish_images (dish_id, image_url, is_primary)
      VALUES (?, ?, ?)
    `;
    const [result]: any = await database.query(query, [
      dish_id,
      image_url,
      is_primary || false,
    ]);

    const [newImageRows]: any = await database.query(
      "SELECT * FROM dish_images WHERE id = ?",
      [result.insertId]
    );

    res.status(201).json({ success: true, data: newImageRows[0] });
  } catch (error: any) {
    console.error("Error adding image:", error);
    res.status(500).json({ success: false, message: error.message });
  }
};

// ✅ Upload and add multiple images for a dish
export const addMultipleDishImages = [
  upload.array("images", 100),
  async (req: Request, res: Response) => {
    try {
      const files = req.files as Express.Multer.File[];
      const { dish_id } = req.body;

      if (!dish_id) {
        return res.status(400).json({ success: false, message: "dish_id is required" });
      }

      if (!files || files.length === 0) {
        return res.status(400).json({ success: false, message: "No files uploaded" });
      }

      // Convert uploaded files to image records
      const imageRecords = files.map((file, index) => ({
        dish_id,
        image_url: `/uploads/${file.filename}`,
        is_primary: index === 0 ? 1 : 0,
      }));

      const values = imageRecords.map((img) => [img.dish_id, img.image_url, img.is_primary]);

      await database.query(
        "INSERT INTO dish_images (dish_id, image_url, is_primary) VALUES ?",
        [values]
      );

      res.status(201).json({
        success: true,
        message: "Images uploaded and saved successfully",
        images: imageRecords,
      });
    } catch (error: any) {
      console.error("Error adding multiple images:", error);
      res.status(500).json({ success: false, message: error.message });
    }
  },
];

// ✅ Get all images for a dish
export const getDishImages = async (req: Request, res: Response) => {
  try {
    const { dishId } = req.params;

    const [images]: any = await database.query(
      "SELECT * FROM dish_images WHERE dish_id = ? ORDER BY is_primary DESC",
      [dishId]
    );

    res.json({ success: true, data: images || [] });
  } catch (error: any) {
    console.error("Error fetching images:", error);
    res.status(500).json({ success: false, message: error.message });
  }
};

// ✅ Update primary image
export const updateDishImage = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { is_primary } = req.body;

    await database.query("UPDATE dish_images SET is_primary = ? WHERE id = ?", [is_primary, id]);

    const [updatedRows]: any = await database.query(
      "SELECT * FROM dish_images WHERE id = ?",
      [id]
    );

    res.json({ success: true, data: updatedRows[0] });
  } catch (error: any) {
    console.error("Error updating image:", error);
    res.status(500).json({ success: false, message: error.message });
  }
};

// ✅ Delete an image
export const deleteDishImage = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    await database.query("DELETE FROM dish_images WHERE id = ?", [id]);
    res.json({ success: true, message: "Image deleted successfully" });
  } catch (error: any) {
    console.error("Error deleting image:", error);
    res.status(500).json({ success: false, message: error.message });
  }
};
