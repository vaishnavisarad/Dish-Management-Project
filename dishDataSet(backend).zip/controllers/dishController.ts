import { Request, Response } from 'express';
import database from '../config/database.js'; // ES module
import axios from "axios";
import path from "path";
import dotenv from "dotenv";
dotenv.config();

const VITE_API_BASE_URL = process.env.VITE_API_BASE_URL; // Keep as string, NOT Number

const CLIP_SERVICE_URL = process.env.CLIP_SERVICE_URL; 

if (!CLIP_SERVICE_URL) {
  throw new Error("CLIP_SERVICE_URL is not defined in .env");
}

// ✅ GET all dishes with images (search, pagination, cuisine_group filter)
export const getAllDishes = async (req: Request, res: Response) => {
  try {
    const searchQuery = req.query.search as string;
    const cuisineGroup = req.query.cuisine_group as string; // 🔥 dataset filter
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const offset = (page - 1) * limit;

    let whereClause = '';
    let queryParams: any[] = [];

    // 🔍 Search filter
    if (searchQuery && searchQuery.trim()) {
      const searchTerm = `%${searchQuery.trim()}%`;
      whereClause = ` WHERE (
        name LIKE ? OR
        location_country LIKE ? OR
        location_region LIKE ? OR
        location_city LIKE ? OR
        dish_type LIKE ? OR
        main_ingredient LIKE ? OR
        cooking_method LIKE ? OR
        cuisine_style LIKE ? OR
        cuisine_group LIKE ? OR
        taste_profile LIKE ? OR
        occasion LIKE ? OR
        food_type LIKE ? OR
        description LIKE ? OR
        famous_for LIKE ?
      )`;
      queryParams = Array(14).fill(searchTerm);
    }

    // 🌍 Dataset filter (Indian / French / European)
    if (cuisineGroup && cuisineGroup.trim()) {
      whereClause += whereClause ? " AND" : " WHERE";
      whereClause += " cuisine_group = ?";
      queryParams.push(cuisineGroup.trim());
    }

    // 🔢 Count query
    const countQuery = `SELECT COUNT(*) AS total FROM dishes${whereClause}`;
    const [countResult]: any = await database.query(countQuery, queryParams);
    const total = countResult[0].total;

    // 📦 Data query
    const query = `
      SELECT *
      FROM dishes
      ${whereClause}
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
    `;

    const [dishes]: any = await database.query(
      query,
      [...queryParams, limit, offset]
    );

    // 🖼 Fetch images for each dish
    const dishesWithImages = await Promise.all(
      dishes.map(async (dish: any) => {
        const [images]: any = await database.query(
          `SELECT id, dish_id, image_url
           FROM dish_images
           WHERE dish_id = ?
           ORDER BY is_primary DESC`,
          [dish.id]
        );

        return {
          id: dish.id,
          name: dish.name,
          location_country: dish.location_country,
          location_region: dish.location_region,
          location_city: dish.location_city,
          dish_type: dish.dish_type,
          main_ingredient: dish.main_ingredient,
          cooking_method: dish.cooking_method,
          cuisine_style: dish.cuisine_style,
          cuisine_group: dish.cuisine_group, // ✅ NEW
          taste_profile: dish.taste_profile,
          occasion: dish.occasion,
          description: dish.description,
          famous_for: dish.famous_for,
          food_type: dish.food_type,
          created_at: dish.created_at,
          updated_at: dish.updated_at,
          dish_images: images || []
        };
      })
    );

    // ✅ Response
    res.json({
      success: true,
      data: dishesWithImages,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error: any) {
    console.error("❌ Error fetching dishes:", error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};


// ✅ GET dish by ID
export const getDishById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const [dishResult]: any = await database.query('SELECT * FROM dishes WHERE id = ?', [id]);
    const dish = dishResult[0];

    if (!dish) return res.status(404).json({ success: false, message: 'Dish not found' });

    const [images]: any = await database.query(
      'SELECT * FROM dish_images WHERE dish_id = ? ORDER BY is_primary DESC',
      [id]
    );

    res.json({
      success: true,
      data: {
        id: dish.id,
        name: dish.name,
        location_country: dish.location_country,
        location_region: dish.location_region,
        location_city: dish.location_city,
        dish_type: dish.dish_type,
        main_ingredient: dish.main_ingredient,
        cooking_method: dish.cooking_method,
        cuisine_style: dish.cuisine_style,
        cuisine_group: dish.cuisine_group, // ✅ add
        taste_profile: dish.taste_profile,
        occasion: dish.occasion,
        description: dish.description,
        famous_for: dish.famous_for,
        food_type: dish.food_type, // ✅ veg/non-veg
        created_at: dish.created_at,
        updated_at: dish.updated_at,
        dish_images: images || []
      }
    });
  } catch (error: any) {
    console.error('Error fetching dish:', error);
    res.status(500).json({ success: false, message: error.message });
  }
};

export const checkDishExists = async (req: Request, res: Response) => {
  try {
    const { name } = req.query;

    if (!name || !String(name).trim()) {
      console.log("❌ Dish name not provided");
      return res
        .status(400)
        .json({ exists: false, message: "Dish name required" });
    }

    const trimmedName = String(name).trim();
    console.log("🔍 Checking dish in DB:", trimmedName);

    // Test database connection
    const [dbNameRows]: any = await database.query("SELECT DATABASE() AS db");
    console.log("✅ Connected to database:", dbNameRows[0].db);

    // Query for the dish (case-insensitive)
    const [rows]: any = await database.query(
      "SELECT * FROM dishes WHERE LOWER(name) = LOWER(?)",
      [trimmedName]
    );
    console.log("Query result rows:", rows);

    if (rows.length > 0) {
      console.log("✅ Dish exists:", rows[0].name);
      return res.json({ exists: true, message: "Dish already exists" });
    } else {
      console.log("⚠️ Dish not found");
      return res.json({ exists: false, message: "Dish not found" });
    }
  } catch (err: any) {
    console.error("❌ Error checking dish:", err);
    return res.status(500).json({ exists: false, message: "Server error" });
  }
};


// ✅ CREATE dish with optional images
export const createDish = async (req: Request, res: Response) => {
  try {
    const { images, food_type, name, location_country, ...dishData } = req.body;

    // 1️⃣ Check for duplicate by name + country
    const [existing]: any = await database.query(
      "SELECT * FROM dishes WHERE name = ? AND location_country = ?",
      [name, location_country]
    );

    if (existing.length > 0) {
      const existingDishId = existing[0].id;
      const [dishImages]: any = await database.query(
        "SELECT * FROM dish_images WHERE dish_id = ? ORDER BY is_primary DESC",
        [existingDishId]
      );

      return res.status(400).json({
        success: false,
        message: "Dish already exists",
        existingDish: { ...existing[0], dish_images: dishImages },
      });
    }

    // 2️⃣ No duplicate – insert new dish
    const filteredDishData = Object.fromEntries(
      Object.entries({ ...dishData, food_type, name, location_country }).filter(([_, v]) => v !== "")
    );

    const keys = [...Object.keys(filteredDishData), "created_at", "updated_at"];
    const values = [...Object.values(filteredDishData), new Date(), new Date()];
    const placeholders = keys.map(() => "?").join(", ");
    const query = `INSERT INTO dishes (${keys.join(", ")}) VALUES (${placeholders})`;

    const [result]: any = await database.query(query, values);
    const dishId = result.insertId;

    // Insert images
    if (Array.isArray(images) && images.length > 0) {
      const imageValues = images.map((img) => [dishId, img.url, img.is_primary ? 1 : 0, new Date()]);
      await database.query(
        "INSERT INTO dish_images (dish_id, image_url, is_primary, created_at) VALUES ?",
        [imageValues]
      );
    }

    const [newDishRows]: any = await database.query("SELECT * FROM dishes WHERE id = ?", [dishId]);
    const [dishImages]: any = await database.query("SELECT * FROM dish_images WHERE dish_id = ?", [dishId]);

    res.status(201).json({
      success: true,
      data: { ...newDishRows[0], dish_images: dishImages },
    });

    console.log("✅ Dish created with images");

      // 2️⃣ AFTER RESPONSE: Calculate feature vectors for each image asynchronously
    processFeatureVectorsForDishImages(dishId);
  } catch (error: any) {
    console.error("❌ Error creating dish:", error);
    res.status(500).json({ success: false, message: error.message });
  }
};


// Async function to process images and update feature vectors
async function processFeatureVectorsForDishImages(dishId: number) {
  try {
    const [images]: any = await database.query("SELECT * FROM dish_images WHERE dish_id = ? AND feature_vector IS NULL", [dishId]);
    

    for (const img of images) {
      try {
        const fullImageUrl = `${VITE_API_BASE_URL}${img.image_url}`;

        const image_id=img.id;

        console.log("******fullimagepath",fullImageUrl);
        console.log("image_id:",image_id);

        // Call your vector generation API with the image path
        const response = await axios.post(`${CLIP_SERVICE_URL}/generate-vector`, {
          image_path: fullImageUrl,
          image_id:image_id // or the correct full path if needed
        });

        //console.log("Feature vector response:", response.data);

      

        const featureVector = response.data.vector; // Adjust based on your API response format
        console.log("___********____",featureVector.length);

     if (featureVector && Array.isArray(featureVector)) {
  // Convert JS number[] → Float32Array → Buffer
  const float32Vector = new Float32Array(featureVector);
  const vectorBuffer = Buffer.from(float32Vector.buffer);
  console.log("Buffer bytes:", vectorBuffer.length);

  await database.query(
    "UPDATE dish_images SET feature_vector = ? WHERE id = ?",
    [vectorBuffer, img.id]
  );

  console.log(`✅ Updated feature vector for image id: ${img.id}`);
}
 else {
          console.warn(`⚠️ No feature vector returned for image id: ${img.id}`);
        }
      } catch (imgErr) {
        console.error(`❌ Error processing feature vector for image id ${img.id}:`, imgErr);
      }
    }
  } catch (err) {
    console.error(`❌ Error processing feature vectors for dish id ${dishId}:`, err);
  }
}


// ✅ UPDATE dish
export const updateDish = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { images, food_type, deletedImageIds, ...dishData } = req.body;

    const filteredDishData = Object.fromEntries(
      Object.entries({ ...dishData, food_type }).filter(([_, v]) => v !== "")
    );

    filteredDishData.updated_at = new Date();

    const keys = Object.keys(filteredDishData);
    const values = Object.values(filteredDishData);

    if (keys.length > 0) {
      const setClause = keys.map((key) => `${key} = ?`).join(', ');
      await database.query(`UPDATE dishes SET ${setClause} WHERE id = ?`, [...values, id]);
    }
if (deletedImageIds && deletedImageIds.length > 0) {
  console.log("🗑 Deleting images:", deletedImageIds);

  const placeholders = deletedImageIds.map(() => '?').join(',');
  await database.query(
    `DELETE FROM dish_images WHERE id IN (${placeholders})`,
    deletedImageIds
  );

  // 🔥 Remove from FAISS
  for (const imageId of deletedImageIds) {
    try {
      await axios.post(`${CLIP_SERVICE_URL}/remove-vector`, {
        image_id: imageId
      });
      console.log("🧹 FAISS removed image:", imageId);
    } catch (err) {
      console.error("❌ FAISS remove failed:", imageId, err);
    }
  }
}


    // ✅ Handle images separately
    if (images && Array.isArray(images)) {
      for (const img of images) {
        if (img.id) {
          await database.query(
            "UPDATE dish_images SET image_url = ?, is_primary = ? WHERE id = ?",
            [img.url, img.is_primary ? 1 : 0, img.id]
          );
        } else {
          await database.query(
            "INSERT INTO dish_images (dish_id, image_url, is_primary, created_at) VALUES (?, ?, ?, ?)",
            [id, img.url, img.is_primary ? 1 : 0, new Date()]
          );
        }
      }
    }

    const [updatedDishRows]: any = await database.query("SELECT * FROM dishes WHERE id = ?", [id]);
    const [updatedImages]: any = await database.query("SELECT * FROM dish_images WHERE dish_id = ?", [id]);

    res.json({ success: true, data: { ...updatedDishRows[0], dish_images: updatedImages } });


    
    // 5️⃣ AFTER RESPONSE: Generate vectors async
    processFeatureVectorsForDishImages(Number(id));

  } catch (error: any) {
    console.error("❌ Error updating dish:", error);
    res.status(500).json({ success: false, message: error.message });
  }
};

// ✅ DELETE dish
export const deleteDish = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    // Delete associated images first
    await database.query('DELETE FROM dish_images WHERE dish_id = ?', [id]);
    await database.query('DELETE FROM dishes WHERE id = ?', [id]);

    res.json({ success: true, message: 'Dish deleted successfully' });
  } catch (error: any) {
    console.error('❌ Error deleting dish:', error);
    res.status(500).json({ success: false, message: error.message });
  }
};

