import path from "path";
import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { fileURLToPath } from "url";

import uploadRoutes from "./routes/uploadRoutes.js";
import dishRoutes from "./routes/dishRoutes.js"; // ✅ Add this

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 5000;


// ✅ ES modules __dirname fix
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);


console.log('Backend __dirname:', __dirname);
console.log('Uploads folder:', path.join(__dirname, 'uploads'));



app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ✅ Serve uploads folder statically
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// ✅ Upload routes
app.use("/api/uploads", uploadRoutes);

// ✅ Dish routes
app.use("/api/dishes", dishRoutes); // ✅ Register dishes route

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "Server is running" });
});




// ✅ Allow all hosts (0.0.0.0)
app.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 Server running on http://0.0.0.0:${PORT}`);
});